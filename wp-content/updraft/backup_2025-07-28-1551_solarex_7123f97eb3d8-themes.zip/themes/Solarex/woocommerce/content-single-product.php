<?php
/**
 * Custom product content for Solarex theme
 * Place in: wp-content/themes/Solarex/woocommerce/content-single-product.php
 */
defined( 'ABSPATH' ) || exit;
global $product;
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>
    <section class="container product-detail-section">
        <div class="product-image-gallery">
            <?php echo $product->get_image( 'full', array( 'class' => 'main-product-image' ) ); ?>
            <?php do_action('woocommerce_product_thumbnails'); ?>
        </div>
        <div class="product-info">
            <h1 class="product-title"><?php the_title(); ?></h1>
            <p class="product-tagline"><?php echo apply_filters('woocommerce_short_description', $post->post_excerpt); ?></p>
            <div class="feature-section">
                <h3>Simple</h3>
                <ul>
                    <li>Eliminate quick installation</li>
                    <li>Easy working mode, set and forget</li>
                    <li>Automatic ON/OFF-Grid switching time &lt;10ms</li>
                </ul>
            </div>
            <div class="feature-section">
                <h3>Efficient</h3>
                <ul>
                    <li>160% PV oversizing, 110% overstock output</li>
                    <li>150-600V wide battery voltage range, 35A fast charge/discharge</li>
                    <li>16A PV current wide adaptation</li>
                </ul>
            </div>
            <div class="feature-section">
                <h3>Intelligent</h3>
                <ul>
                    <li>Smart working logic</li>
                    <li>Generator & heat pump control</li>
                    <li>Mobile & PC platform management</li>
                </ul>
            </div>
            <div class="product-price"><?php echo $product->get_price_html(); ?></div>
            <form class="cart" method="post" enctype="multipart/form-data">
                <div class="d-flex align-items-center mb-3">
                    <span style="font-size: 1.2rem; color: #ffffff; margin-right: 1rem;">Quantity</span>
                    <?php woocommerce_quantity_input(); ?>
                    <button type="submit" class="add-to-cart-btn"><?php esc_html_e('Add to Cart', 'woocommerce'); ?></button>
                </div>
            </form>
            <div class="stock-info"><?php echo wc_get_stock_html( $product ); ?></div>
            <div class="email-notify-group">
                <input type="email" placeholder="your email address">
                <button class="notify-btn">Notify Me</button>
            </div>
        </div>
    </section>
</div>
