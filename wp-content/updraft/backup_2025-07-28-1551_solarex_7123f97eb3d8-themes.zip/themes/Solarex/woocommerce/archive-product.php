<?php
/**
 * Archive Product Template for Solarex Theme
 * Place in: wp-content/themes/Solarex/woocommerce/archive-product.php
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// get_header(); // Remove this, handled by woocommerce_before_main_content hook

?>
<!-- Top Bar -->
<div class="top-bar">
    <div class="container d-flex justify-content-between align-items-center" style="height: 100%;">
        <div class="d-flex align-items-center">
            <span style="color: #000000; margin-right: 0.5rem;">&#x260E; CALL TODAY</span>
            <span style="color: #000000;">+230 220 0050</span>
            <span style="color: #000000; margin-left: 1.5rem; margin-right: 0.5rem;">&#x1F4CD;</span>
            <span style="color: #000000;">191/7, La Tour Koenig, Industrial Park, Port Aux Sables, TROU Mauritius</span>
        </div>
        <div class="d-flex align-items-center">
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F465;</a>
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F4F7;</a>
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F426;</a>
        </div>
        <a href="#" class="specialist-btn">SPECIALIST EPCM</a>
    </div>
</div>
<!-- Navbar -->
<nav class="navbar">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand d-flex align-items-center">
            <img src="https://unsplash.com/photos/a-close-up-of-a-solar-panel-on-a-sunny-day-92xL0sK18kY/download?force=true&w=64&h=64" alt="Solarex Logo" style="height: 30px; margin-right: 10px;">
            SOLAREX
        </a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="#" class="nav-link">PRODUCTS</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CLEARANCE SALES</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CONTACT US</a></li>
        </ul>
        <div class="d-flex align-items-center">
            <div class="search-bar">
                <input type="text" placeholder="Keywords, Product Name, etc.">
                <button class="icon-btn">&#x1F50D;</button>
            </div>
            <button class="icon-btn" style="margin-left: 1rem;">&#x1F464; SIGN IN</button>
            <button class="icon-btn" style="margin-left: 1rem;">&#x1F6CD; VIEW CART</button>
        </div>
    </div>
</nav>
<!-- Breadcrumb -->
<div class="breadcrumb-nav">
    <div class="container">
        <?php woocommerce_breadcrumb(); ?>
    </div>
</div>

<?php
/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_json_ld - 30
 */
do_action( 'woocommerce_before_main_content' );

?>
<header class="woocommerce-products-header">
    <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
        <h1 class="woocommerce-products-header__title page-title"><?php woocommerce_page_title(); ?></h1>
    <?php endif; ?>

    <?php
    /**
     * Hook: woocommerce_archive_description.
     *
     * @hooked woocommerce_taxonomy_archive_description - 10
     * @hooked woocommerce_product_archive_description - 10
     */
    do_action( 'woocommerce_archive_description' );
    ?>
</header>
<?php
if ( woocommerce_product_loop() ) {

    /**
     * Hook: woocommerce_before_shop_loop.
     *
     * @hooked woocommerce_output_all_notices - 10
     * @hooked woocommerce_result_count - 20
     * @hooked woocommerce_catalog_ordering - 30
     */
    do_action( 'woocommerce_before_shop_loop' );

    woocommerce_product_loop_start();

    if ( wc_get_loop_prop( 'total' ) ) {
        while ( have_posts() ) {
            the_post();

            /**
             * Hook: woocommerce_shop_loop.
             */
            do_action( 'woocommerce_shop_loop' );

            wc_get_template_part( 'content', 'product' );
        }
    }

    woocommerce_product_loop_end();

    /**
     * Hook: woocommerce_after_shop_loop.
     *
     * @hooked woocommerce_pagination - 10
     */
    do_action( 'woocommerce_after_shop_loop' );
} else {
    /**
     * Hook: woocommerce_no_products_found.
     *
     * @hooked wc_no_products_found - 10
     */
    do_action( 'woocommerce_no_products_found' );
}

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'woocommerce_after_main_content' );

// get_footer(); // Remove this, handled by woocommerce_after_main_content hook