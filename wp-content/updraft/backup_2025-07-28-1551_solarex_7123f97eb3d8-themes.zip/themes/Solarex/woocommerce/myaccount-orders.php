<?php
/**
 * Template Name: Custom My Account Orders Page
 * WooCommerce My Account Orders Page Override for Solarex Theme
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
get_header();
?>
<div class="top-bar">
    <!-- Top bar content (social icons, contact info, etc.) -->
</div>
<nav class="navbar container">
    <div class="navbar-brand">Solarex</div>
    <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="/shop">Shop</a></li>
        <li class="nav-item"><a class="nav-link" href="/cart">Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="/my-account">Account</a></li>
    </ul>
    <form class="search-bar">
        <input type="text" placeholder="Search products...">
        <button class="icon-btn" type="submit"><span class="dashicons dashicons-search"></span></button>
    </form>
</nav>
<div class="breadcrumb-nav container">
    <?php woocommerce_breadcrumb(); ?>
</div>
<div class="container myaccount-section" style="margin-top:100px;">
    <h1 class="product-title">My Orders</h1>
    <div class="product-info">
        <?php wc_get_template( 'myaccount/orders.php' ); ?>
    </div>
</div>
<footer class="footer">
    <div class="footer-logo">Solarex</div>
    <div class="footer-contact-info">
        <p>Email: info@solarex.com</p>
        <p>Phone: +123456789</p>
    </div>
    <div class="footer-links-group">
        <div class="footer-links-column">
            <h5>Shop</h5>
            <ul><li><a href="/shop">All Products</a></li></ul>
        </div>
        <div class="footer-links-column">
            <h5>Account</h5>
            <ul><li><a href="/my-account">My Account</a></li></ul>
        </div>
    </div>
    <div class="footer-social-icons">
        <a href="#">FB</a><a href="#">TW</a><a href="#">IG</a>
    </div>
    <div class="footer-copyright">&copy; 2025 Solarex. All rights reserved.</div>
</footer>
<?php get_footer(); ?>
