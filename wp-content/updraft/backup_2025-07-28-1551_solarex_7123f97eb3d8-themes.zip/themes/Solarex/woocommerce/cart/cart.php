<?php
/**
 * WooCommerce Cart Page Template Override for Solarex Theme
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="top-bar"></div>
<nav class="navbar container">
    <div class="navbar-brand">Solarex</div>
    <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="/shop">Shop</a></li>
        <li class="nav-item"><a class="nav-link" href="/cart">Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="/my-account">Account</a></li>
    </ul>
    <form class="search-bar">
        <input type="text" placeholder="Search products...">
        <button class="icon-btn" type="submit"><span class="dashicons dashicons-search"></span></button>
    </form>
</nav>
<div class="breadcrumb-nav container">
    <?php woocommerce_breadcrumb(); ?>
</div>
<div class="container cart-section" style="margin-top:100px;">
    <h1 class="product-title">Your Cart</h1>
    <div class="product-info">
        <?php
        // WooCommerce default cart content
        do_action( 'woocommerce_before_cart' );
        if ( WC()->cart->is_empty() ) {
            wc_get_template( 'cart/cart-empty.php' );
        } else {
            // Main cart form and content
            ?>
            <form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
                <?php do_action( 'woocommerce_before_cart_table' ); ?>
                <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="product-remove">&nbsp;</th>
                            <th class="product-thumbnail">&nbsp;</th>
                            <th class="product-name">Product</th>
                            <th class="product-price">Price</th>
                            <th class="product-quantity">Quantity</th>
                            <th class="product-subtotal">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php do_action( 'woocommerce_before_cart_contents' ); ?>
                        <?php
                        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                            $_product   = $cart_item['data'];
                            $product_id = $cart_item['product_id'];
                            if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 ) {
                                ?>
                                <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
                                    <td class="product-remove">
                                        <?php
                                            echo apply_filters( 'woocommerce_cart_item_remove_link',
                                                sprintf( '<a href="%s" class="remove" aria-label="Remove %s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                                                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                                                    esc_html( $_product->get_name() ),
                                                    esc_attr( $product_id ),
                                                    esc_attr( $_product->get_sku() )
                                                ),
                                                $cart_item_key );
                                        ?>
                                    </td>
                                    <td class="product-thumbnail">
                                        <?php
                                            $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
                                            if ( ! $_product->is_visible() ) {
                                                echo $thumbnail;
                                            } else {
                                                printf( '<a href="%s">%s</a>', esc_url( $_product->get_permalink( $cart_item ) ), $thumbnail );
                                            }
                                        ?>
                                    </td>
                                    <td class="product-name" data-title="Product">
                                        <?php
                                            if ( ! $_product->is_visible() ) {
                                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) );
                                            } else {
                                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $_product->get_permalink( $cart_item ) ), $_product->get_name() ), $cart_item, $cart_item_key ) );
                                            }
                                            // Meta data
                                            echo wc_get_formatted_cart_item_data( $cart_item );
                                            // Backorder notification
                                            if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
                                                echo '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'woocommerce' ) . '</p>';
                                            }
                                        ?>
                                    </td>
                                    <td class="product-price" data-title="Price">
                                        <?php
                                            echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
                                        ?>
                                    </td>
                                    <td class="product-quantity" data-title="Quantity">
                                        <?php
                                            if ( $_product->is_sold_individually() ) {
                                                $product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
                                            } else {
                                                $product_quantity = woocommerce_quantity_input( array(
                                                    'input_name'  => "cart[{$cart_item_key}][qty]",
                                                    'input_value' => $cart_item['quantity'],
                                                    'max_value'   => $_product->get_max_purchase_quantity(),
                                                    'min_value'   => '0',
                                                    'product_name'=> $_product->get_name(),
                                                ), $_product, false );
                                            }
                                            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
                                        ?>
                                    </td>
                                    <td class="product-subtotal" data-title="Total">
                                        <?php
                                            echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                        <?php do_action( 'woocommerce_cart_contents' ); ?>
                    </tbody>
                </table>
                <?php do_action( 'woocommerce_after_cart_contents' ); ?>
                <div class="cart-actions">
                    <?php if ( wc_coupons_enabled() ) { ?>
                        <div class="coupon">
                            <label for="coupon_code">Coupon:</label>
                            <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code" />
                            <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply coupon</button>
                        </div>
                    <?php } ?>
                    <button type="submit" class="button" name="update_cart" value="Update cart">Update cart</button>
                </div>
                <?php do_action( 'woocommerce_cart_actions' ); ?>
                <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
            </form>
            <div class="cart-totals">
                <?php woocommerce_cart_totals(); ?>
            </div>
            <?php
        }
        do_action( 'woocommerce_after_cart' );
        ?>
    </div>
</div>
<footer class="footer">
    <div class="footer-logo">Solarex</div>
    <div class="footer-contact-info">
        <p>Email: info@solarex.com</p>
        <p>Phone: +123456789</p>
    </div>
    <div class="footer-links-group">
        <div class="footer-links-column">
            <h5>Shop</h5>
            <ul><li><a href="/shop">All Products</a></li></ul>
        </div>
        <div class="footer-links-column">
            <h5>Account</h5>
            <ul><li><a href="/my-account">My Account</a></li></ul>
        </div>
    </div>
    <div class="footer-social-icons">
        <a href="#">FB</a><a href="#">TW</a><a href="#">IG</a>
    </div>
    <div class="footer-copyright">&copy; 2025 Solarex. All rights reserved.</div>
</footer>
