<?php
/**
 * WooCommerce My Account Orders Endpoint Override for Solarex Theme
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>
<div class="top-bar">
    <div class="container d-flex justify-content-between align-items-center" style="height: 100%;">
        <div class="d-flex align-items-center">
            <span style="color: #000000; margin-right: 0.5rem;">&#x260E; CALL TODAY</span>
            <span style="color: #000000;">+230 220 0050</span>
            <span style="color: #000000; margin-left: 1.5rem; margin-right: 0.5rem;">&#x1F4CD;</span>
            <span style="color: #000000;">191/7, La Tour Koenig, Industrial Park, Port Aux Sables, TROU Mauritius</span>
        </div>
        <div class="d-flex align-items-center">
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F465;</a>
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F4F7;</a>
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F426;</a>
        </div>
        <a href="#" class="specialist-btn">SPECIALIST EPCM</a>
    </div>
</div>

<nav class="navbar">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand d-flex align-items-center">
            <img src="https://unsplash.com/photos/a-close-up-of-a-solar-panel-on-a-sunny-day-92xL0sK18kY/download?force=true&w=64&h=64" alt="Solarex Logo" style="height: 30px; margin-right: 10px;">
            SOLAREX
        </a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="nav-link">PRODUCTS</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CLEARANCE SALES</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CONTACT US</a></li>
        </ul>
        <div class="d-flex align-items-center">
            <div class="search-bar">
                <input type="text" placeholder="Keywords, Product Name, etc.">
                <button class="icon-btn">&#x1F50D;</button>
            </div>
            <button class="icon-btn" style="margin-left: 1rem;">&#x1F464; SIGN IN</button>
            <button class="icon-btn" style="margin-left: 1rem;" onclick="window.location.href='<?php echo wc_get_cart_url(); ?>'">&#x1F6CD; VIEW CART</button>
        </div>
    </div>
</nav>
    <div class="navbar-brand">Solarex</div>
    <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="/shop">Shop</a></li>
        <li class="nav-item"><a class="nav-link" href="/cart">Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="/my-account">Account</a></li>
    </ul>
    <form class="search-bar">
        <input type="text" placeholder="Search products...">
        <button class="icon-btn" type="submit"><span class="dashicons dashicons-search"></span></button>
    </form>
</nav>
<div class="breadcrumb-nav">
    <div class="container">
        <?php woocommerce_breadcrumb(); ?>
    </div>
</div>

<div class="container boxed-section" style="margin-top:100px; max-width:1200px;">
    <h1 class="product-title">Orders</h1>
    <div class="product-info">
        <?php
        // Load WooCommerce default orders template
        wc_get_template( 'myaccount/orders.php', array(), '', WC()->plugin_path() . '/templates/' );
        ?>
    </div>
</div>
<footer class="footer">
    <div class="footer-logo">Solarex</div>
    <div class="footer-contact-info">
        <p>Email: info@solarex.com</p>
        <p>Phone: +123456789</p>
    </div>
    <div class="footer-links-group">
        <div class="footer-links-column">
            <h5>Shop</h5>
            <ul><li><a href="/shop">All Products</a></li></ul>
        </div>
        <div class="footer-links-column">
            <h5>Account</h5>
            <ul><li><a href="/my-account">My Account</a></li></ul>
        </div>
    </div>
    <div class="footer-social-icons">
        <a href="#">FB</a><a href="#">TW</a><a href="#">IG</a>
    </div>
    <div class="footer-copyright">&copy; 2025 Solarex. All rights reserved.</div>
</footer>
