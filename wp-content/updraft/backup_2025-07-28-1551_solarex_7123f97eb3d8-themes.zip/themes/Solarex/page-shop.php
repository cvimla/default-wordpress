<?php
/**
 * Template Name: Custom Shop Page
 *
 * This is the template for the custom shop page.
 *
 * @package Solarex
 */

get_header();
?>

<!-- Top Bar -->
<div class="top-bar">
    <div class="container d-flex justify-content-between align-items-center" style="height: 100%;">
        <div class="d-flex align-items-center">
            <span style="color: #000000; margin-right: 0.5rem;">&#x260E; CALL TODAY</span>
            <span style="color: #000000;">+230 220 0050</span>
            <span style="color: #000000; margin-left: 1.5rem; margin-right: 0.5rem;">&#x1F4CD;</span>
            <span style="color: #000000;">191/7, La Tour Koenig, Industrial Park, Port Aux Sables, TROU Mauritius</span>
        </div>
        <div class="d-flex align-items-center">
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F465;</a> <!-- LinkedIn -->
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F4F7;</a> <!-- Instagram -->
            <a href="#" class="social-icon" style="color: #0e131f;">&#x1F426;</a> <!-- Twitter -->
        </div>
        <a href="#" class="specialist-btn">SPECIALIST EPCM</a>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand d-flex align-items-center">
            <img src="https://unsplash.com/photos/a-close-up-of-a-solar-panel-on-a-sunny-day-92xL0sK18kY/download?force=true&w=64&h=64" alt="Solarex Logo" style="height: 30px; margin-right: 10px;">
            SOLAREX
        </a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="nav-link">PRODUCTS</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CLEARANCE SALES</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CONTACT US</a></li>
        </ul>
        <div class="d-flex align-items-center">
            <div class="search-bar">
                <input type="text" placeholder="Keywords, Product Name, etc.">
                <button class="icon-btn">&#x1F50D;</button> <!-- Search icon -->
            </div>
            <button class="icon-btn" style="margin-left: 1rem;">&#x1F464; SIGN IN</button> <!-- User icon -->
            <button class="icon-btn" style="margin-left: 1rem;" onclick="window.location.href='<?php echo wc_get_cart_url(); ?>'">&#x1F6CD; VIEW CART</button> <!-- Cart icon -->
        </div>
    </div>
</nav>

<!-- Breadcrumb -->
<div class="breadcrumb-nav">
    <div class="container">
        <?php woocommerce_breadcrumb(); ?>
    </div>
</div>

<div class="shop-container">
    <div class="shop-wrapper">
        <!-- Left Sidebar -->
        <aside class="shop-sidebar">
            <h1 class="sidebar-title">Select<br>Models</h1>
            
            <div class="filter-section">
                <!-- All Products Filter -->
                <div class="filter-item">
                    <input type="radio" name="category_filter" value="" id="all_products" checked>
                    <label for="all_products">ALL</label>
                </div>
                
                <!-- Dynamic Category Filters -->
                <?php
                // Get product categories
                $categories = get_terms( array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => true,
                    'parent' => 0 // Only top-level categories
                ) );
                
                if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
                    foreach ( $categories as $category ) {
                        echo '<div class="filter-item">';
                        echo '<input type="radio" name="category_filter" value="' . esc_attr( $category->term_id ) . '" id="cat_' . esc_attr( $category->term_id ) . '">';
                        echo '<label for="cat_' . esc_attr( $category->term_id ) . '">' . esc_html( $category->name ) . '</label>';
                        echo '</div>';
                    }
                }
                ?>
            </div>

            <!-- Price Filter Section -->
            <div class="price-filter-section">
                <form method="get" class="price-filter" id="price-filter-form">
                    <div id="price-range-slider"></div>
                    <span id="price-range-display" style="display: block; text-align: center; margin-top: 15px; font-weight: bold; color: #ffffff;"></span>
                    <input type="hidden" name="min_price" id="min_price_hidden" value="">
                    <input type="hidden" name="max_price" id="max_price_hidden" value="">
                    <button type="submit" class="filter-button" style="margin-top: 20px;">FILTER BY PRICE</button>
                </form>
            </div>
        </aside>

        <!-- Products Section -->
        <main class="products-section">
            <div class="section-header">
                <h2 class="page-title">Our Products</h2>
            </div>

            <div class="loading-spinner" id="loading-spinner">
                Loading products...
            </div>

            <div id="products-container">
                <?php
                // Get current category filter
                $current_category = isset($_GET['category_filter']) ? intval($_GET['category_filter']) : 0;
                
                // Create a new query for products
                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => -1,
                );
                
                // Add category filter if selected
                if ($current_category > 0) {
                    $args['product_cat'] = get_term_by('id', $current_category, 'product_cat')->slug;
                }
                
                $loop = new WP_Query($args);
                
                if ($loop->have_posts()) {
                    echo '<div class="products-grid">';
                    
                    while ($loop->have_posts()) : $loop->the_post();
                        global $product;
                        
                        echo '<div class="product-card">';
                        echo '<a href="' . get_permalink() . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">';
                        echo '<div class="product-image">' . $product->get_image() . '</div>';
                        echo '<h3 class="product-title">' . $product->get_name() . '</h3>';
                        echo '<span class="price">' . $product->get_price_html() . '</span>';
                        echo '</a>';
                        echo '<a href="' . esc_url( add_query_arg( 'add-to-cart', $product->get_id(), home_url( '/' ) ) ) . '" class="button add_to_cart_button">Add to cart</a>';
                        echo '</div>';
                    endwhile;
                    
                    echo '</div>';
                } else {
                    echo '<p>No products found</p>';
                }
                wp_reset_postdata();
                ?>
            </div>
        </main>
    </div>
</div>

<?php get_footer(); ?>