jQuery(document).ready(function($) {
    // Utility debounce function to limit rapid-fire events
    function debounce(func, wait = 600, immediate = false) {
        let timeout;
        return function() {
            const context = this, args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                func.apply(context, args);
            }, wait);
        };
    }

    // Initialize only on shop pages
    if (!$('body').hasClass('page-template-page-shop-php') && 
        !$('body').hasClass('woocommerce') && 
        !$('body').hasClass('archive') && 
        !$('.shop-container').length) {
        return;
    }

    // Event listeners need to be re-bound after AJAX update
    function bindFilterEvents() {
        // Handle category filter clicks
        $('input[name="category_filter"]').off('change').on('change', function() {
            debouncedFilter();
        });

        // Optional: Add more event bindings here that should persist after AJAX
    }

    bindFilterEvents();
    
    // Initialize Price Slider with dynamic min/max from server
    function initPriceSlider(min, max) {
        if ($("#price-range-slider").length) {
            $("#price-range-slider").slider({
                range: true,
                min: min,
                max: max,
                values: [min, max],
                slide: function(event, ui) {
                    $("#price-range-display").text('₨' + ui.values[0] + ' - ₨' + ui.values[1]);
                    $("#min_price_hidden").val(ui.values[0]);
                    $("#max_price_hidden").val(ui.values[1]);
                },
                stop: function(event, ui) {
                    filterProducts();
                }
            });
            $("#price-range-display").text('₨' + min + ' - ₨' + max);
            $("#min_price_hidden").val(min);
            $("#max_price_hidden").val(max);
        }
    }

    // Fetch min/max prices on page load
    $.ajax({
        url: solarex_shop_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'get_min_max_prices',
            nonce: solarex_shop_ajax.nonce
        },
        success: function(response) {
            if (response.success && response.data) {
                initPriceSlider(parseFloat(response.data.min_price), parseFloat(response.data.max_price));
            }
        },
        error: function() {
            // fallback to 0-10000 if error
            initPriceSlider(0, 10000);
        }
    });

    // Handle price filter form submission (still useful for direct submission if needed)
    $('#price-filter-form').on('submit', function(e) {
        e.preventDefault();
        filterProducts();
    });
    
    const debouncedFilter = debounce(function() {
        filterProducts();
    });

    function filterProducts() {
        const selectedCategory = $('input[name="category_filter"]:checked').val();
        const minPrice = $('#min_price_hidden').val(); // Get from hidden input
        const maxPrice = $('#max_price_hidden').val(); // Get from hidden input

        // Optionally fetch new price range when category changes
        if (selectedCategory && (typeof lastSentCategory === 'undefined' || lastSentCategory !== selectedCategory)) {
            fetchPriceRange(selectedCategory);
        }

        // Show loading spinner
        $('#loading-spinner').show();
        $('#products-grid').hide();

        // Build URL parameters
        const params = new URLSearchParams();
        if (selectedCategory) {
            params.append('category_filter', selectedCategory);
        }
        if (minPrice) {
            params.append('min_price', minPrice);
        }
        if (maxPrice) {
            params.append('max_price', maxPrice);
        }

        // Update URL without page reload
        const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
        window.history.pushState({}, '', newUrl);

        // AJAX request to filter products
        $.ajax({
            url: solarex_shop_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_products',
                category_filter: selectedCategory,
                min_price: minPrice,
                max_price: maxPrice,
                nonce: solarex_shop_ajax.nonce
            },
            success: function(response) {
                $('#loading-spinner').hide();
                $('#products-container').html(response);
                $('#products-grid').show();

                // Rebind events after AJAX load
                bindFilterEvents();

                // Re-initialize any needed components after AJAX update
                initializeComponents();
            },
            error: function(xhr, status, error) {
                $('#loading-spinner').hide();
                $('#products-grid').show();
                console.error('AJAX Error:', status, error);
                alert('Something went wrong. Please try again.');
            }
        });

        // Store last sent category
        lastSentCategory = selectedCategory;
    }
    
    function initializeComponents() {
        // Any components that need re-initialization after AJAX updates
    }
    
    // Function to fetch dynamic price range via AJAX
    function fetchPriceRange(category) {
        $.ajax({
            url: solarex_shop_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'get_min_max_prices',
                category_filter: category,
                nonce: solarex_shop_ajax.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    const { min_price, max_price } = response.data;
                    
                    // Update global price range
                    window.minPriceOverall = parseFloat(min_price);
                    window.maxPriceOverall = parseFloat(max_price);

                    // Reinitialize slider with new values
                    if ($("#price-range-slider").length) {
                        $("#price-range-slider").slider("option", "min", window.minPriceOverall);
                        $("#price-range-slider").slider("option", "max", window.maxPriceOverall);
                        $("#price-range-slider").slider("values", [window.minPriceOverall, window.maxPriceOverall]);
                        
                        $("#price-range-display").text('₨' + window.minPriceOverall + ' - ₨' + window.maxPriceOverall);
                        $("#min_price_hidden").val(window.minPriceOverall);
                        $("#max_price_hidden").val(window.maxPriceOverall);
                    }
                }
            },
            error: function() {
                console.error('Failed to fetch price range');
            }
        });
    }

    // Set initial filter state based on URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const categoryParam = urlParams.get('category_filter');
    const minPriceParam = urlParams.get('min_price');
    const maxPriceParam = urlParams.get('max_price');

    if (categoryParam) {
        $('input[name="category_filter"][value="' + categoryParam + '"]').prop('checked', true);
        
        // Fetch price range based on selected category
        fetchPriceRange(categoryParam);
    }

    // Set slider values and display based on URL parameters
    if (minPriceParam && maxPriceParam && $("#price-range-slider").length) {
        $("#price-range-slider").slider("values", [parseFloat(minPriceParam), parseFloat(maxPriceParam)]);
        $("#price-range-display").text('₨' + minPriceParam + ' - ₨' + maxPriceParam);
        $("#min_price_hidden").val(minPriceParam);
        $("#max_price_hidden").val(maxPriceParam);
    }

    // Expose for global access if needed
    window.fetchPriceRange = fetchPriceRange;
});