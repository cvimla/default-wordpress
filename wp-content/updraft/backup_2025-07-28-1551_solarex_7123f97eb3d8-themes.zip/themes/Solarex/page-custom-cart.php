<?php
/**
 * Template Name: Solarex Custom Cart
 *
 * This is the template for the WooCommerce Cart page with Solarex design.
 *
 * @package Solarex
 */

// Ensure WordPress environment is loaded if this file is accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solarex | Your Cart</title>
    <meta name="description" content="Review your items in the Solarex shopping cart.">
    <!-- Google Fonts: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* Global Styles & Resets */
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            line-height: 1.5;
            color: #ffffff;
            background-color: #0e131f; /* Secondary color */
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }
        *, *::before, *::after {
            box-sizing: border-box;
        }
        h1, h2, h3, h4, h5, h6 {
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-weight: 700;
            line-height: 1.2;
            color: #ffffff;
        }
        p {
            margin-top: 0;
            margin-bottom: 1rem;
        }
        a {
            color: #a4ff3d; /* Primary color for links */
            text-decoration: none;
        }
        a:hover {
            color: #d6ff7f; /* Lighter primary for hover */
            text-decoration: underline;
        }
        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        /* Utility Classes (mimicking common patterns for responsive layout) */
        .container {
            width: 100%;
            padding-right: 1rem;
            padding-left: 1rem;
            margin-right: auto;
            margin-left: auto;
            max-width: 1200px; /* Adjust as needed */
        }
        .d-flex { display: flex; }
        .flex-wrap { flex-wrap: wrap; }
        .justify-content-between { justify-content: space-between; }
        .justify-content-center { justify-content: center; }
        .align-items-center { align-items: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .m-0 { margin: 0; }
        .mb-1 { margin-bottom: 0.25rem; }
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-3 { margin-bottom: 1rem; }
        .mb-4 { margin-bottom: 1.5rem; }
        .mt-4 { margin-top: 1.5rem; }
        .py-4 { padding-top: 1.5rem; padding-bottom: 1.5rem; }
        .px-3 { padding-left: 1rem; padding-right: 1rem; }
        .p-3 { padding: 1rem; }
        .p-4 { padding: 1.5rem; }
        .rounded { border-radius: 0.5rem; }
        .shadow { box-shadow: 0 4px 8px rgba(0,0,0,0.2); }

        /* Specific Component Styles */
        .top-bar {
            background-color: #f0f0f0;
            height: 2.5rem;
            font-size: 0.875rem;
            color: #000000;
            display: flex;
            align-items: center;
        }
        .top-bar .social-icon {
            color: #0e131f;
            margin-left: 0.5rem;
            font-size: 1rem;
        }
        .top-bar .contact-info {
            margin-left: 1rem;
        }

        .navbar {
            background-color: #0e131f;
            padding: 1rem 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar-brand {
            font-size: 1.5rem;
            color: #ffffff;
            font-weight: 700;
        }
        .navbar-nav {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-item {
            margin-left: 1.5rem;
        }
        .nav-link {
            color: #ffffff;
            font-weight: 400;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #a4ff3d;
            text-decoration: none;
        }
        .specialist-btn {
            background-color: #a4ff3d;
            color: #000000;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        .specialist-btn:hover {
            background-color: #d6ff7f;
        }
        .search-bar {
            background-color: #1a1a1a;
            border-radius: 0.375rem;
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
            width: 250px; /* Adjust as needed */
        }
        .search-bar input {
            background: none;
            border: none;
            outline: none;
            color: #ffffff;
            width: 100%;
        }
        .search-bar input::placeholder {
            color: #777777;
        }
        .icon-btn {
            background: none;
            border: none;
            color: #a4ff3d;
            font-size: 1.2rem;
            cursor: pointer;
            margin-left: 0.5rem;
        }

        .breadcrumb-nav {
            background-color: #0e131f;
            padding: 0.75rem 0;
            font-size: 0.9rem;
            color: #777777;
        }
        .breadcrumb-nav a {
            color: #777777;
        }
        .breadcrumb-nav a:hover {
            color: #a4ff3d;
        }
        .breadcrumb-nav span {
            margin: 0 0.5rem;
        }

        /* WooCommerce specific styles for cart page */
        .woocommerce-cart-form, .cart-collaterals {
            background-color: #1a1a1a;
            padding: 2rem;
            border-radius: 1rem;
            margin-bottom: 2rem;
        }
        .woocommerce table.shop_table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 1rem;
        }
        .woocommerce table.shop_table th, .woocommerce table.shop_table td {
            border: 1px solid #333;
            padding: 0.8rem;
            text-align: left;
            color: #ffffff;
        }
        .woocommerce table.shop_table th {
            background-color: #0e131f;
            color: #a4ff3d;
        }
        .woocommerce .quantity .qty {
            width: 60px;
            background-color: #0e131f;
            color: #ffffff;
            border: 1px solid #777;
            padding: 0.5rem;
            border-radius: 0.3rem;
        }
        .woocommerce .button {
            background-color: #a4ff3d;
            color: #000000;
            padding: 0.8rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 700;
            font-size: 1rem;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .woocommerce .button:hover {
            background-color: #d6ff7f;
        }
        .woocommerce .cart-collaterals .cart_totals {
            background-color: #0e131f;
            padding: 1.5rem;
            border-radius: 1rem;
            border: 1px solid #333;
        }
        .woocommerce .cart-collaterals .cart_totals h2 {
            color: #a4ff3d;
            font-size: 1.8rem;
            margin-bottom: 1rem;
        }
        .woocommerce .cart-collaterals .cart_totals table {
            width: 100%;
        }
        .woocommerce .cart-collaterals .cart_totals table th,
        .woocommerce .cart-collaterals .cart_totals table td {
            border: none;
            padding: 0.5rem 0;
            color: #ffffff;
        }
        .woocommerce .cart-collaterals .cart_totals .order-total th,
        .woocommerce .cart-collaterals .cart_totals .order-total td {
            font-weight: 700;
            color: #a4ff3d;
            border-top: 1px solid #333;
            padding-top: 1rem;
        }
        .woocommerce .wc-proceed-to-checkout a.checkout-button {
            display: block;
            text-align: center;
            margin-top: 1.5rem;
        }


        .footer {
            background-color: #0e131f;
            color: #ffffff;
            padding: 3rem 0;
            text-align: center;
        }
        .footer-logo {
            width: 100px; /* Adjust as needed */
            height: auto;
            margin-bottom: 1rem;
        }
        .footer-contact-info {
            font-size: 0.9rem;
            color: #ffffff;
            margin-bottom: 1.5rem;
        }
        .footer-contact-info p {
            margin: 0.2rem 0;
        }
        .footer-contact-info a {
            color: #a4ff3d;
        }
        .footer-links-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .footer-links-column {
            flex: 1;
            min-width: 180px;
            margin: 0 1rem;
            text-align: left;
        }
        .footer-links-column h5 {
            font-size: 1rem;
            margin-bottom: 1rem;
            color: #a4ff3d;
        }
        .footer-links-column ul li {
            margin-bottom: 0.5rem;
        }
        .footer-links-column a {
            color: #ffffff;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }
        .footer-links-column a:hover {
            color: #a4ff3d;
        }
        .footer-social-icons {
            margin-top: 2rem;
            margin-bottom: 1rem;
        }
        .footer-social-icons a {
            color: #ffffff;
            margin: 0 0.5rem;
            font-size: 1.2rem;
            transition: color 0.3s ease;
        }
        .footer-social-icons a:hover {
            color: #a4ff3d;
        }
        .footer-copyright {
            color: #777777;
            font-size: 0.85rem;
            margin-top: 1rem;
        }

        /* Responsive adjustments */
        @media (max-width: 767px) {
            .navbar-nav, .search-bar, .icon-btn:not(.menu-toggle) {
                display: none; /* Hide some elements on small screens */
            }
            .navbar {
                flex-wrap: wrap;
                justify-content: center;
            }
            .navbar-brand {
                margin-bottom: 1rem;
            }
            .top-bar .contact-info, .top-bar .social-icon:not(:first-child) {
                display: none;
            }
            .top-bar .specialist-btn {
                display: none;
            }
            .product-detail-section {
                flex-direction: column;
                align-items: center;
            }
            .product-image-gallery, .product-info {
                width: 100%;
                max-width: 100%;
                padding: 1.5rem;
            }
            .product-title {
                font-size: 2rem;
            }
            .product-price {
                font-size: 1.8rem;
            }
            .quantity-selector {
                flex-direction: column;
                align-items: flex-start;
            }
            .quantity-control {
                margin-bottom: 1rem;
            }
            .add-to-cart-btn {
                margin-left: 0;
                width: 100%;
            }
            .stock-info {
                margin-left: 0;
                text-align: left;
            }
            .email-notify-group {
                flex-direction: column;
            }
            .email-notify-group input {
                margin-right: 0;
                margin-bottom: 1rem;
            }
            .notify-btn {
                width: 100%;
            }
            .footer-links-group {
                flex-direction: column;
                align-items: center;
            }
            .footer-links-column {
                text-align: center;
                margin-bottom: 1.5rem;
            }
        }
    </style>
</head>
<body>

    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container d-flex justify-content-between align-items-center" style="height: 100%;">
            <div class="d-flex align-items-center">
                <span style="color: #000000; margin-right: 0.5rem;">&#x260E; CALL TODAY</span>
                <span style="color: #000000;">+230 220 0050</span>
                <span style="color: #000000; margin-left: 1.5rem; margin-right: 0.5rem;">&#x1F4CD;</span>
                <span style="color: #000000;">191/7, La Tour Koenig, Industrial Park, Port Aux Sables, TROU Mauritius</span>
            </div>
            <div class="d-flex align-items-center">
                <a href="#" class="social-icon" style="color: #0e131f;">&#x1F465;</a> <!-- LinkedIn -->
                <a href="#" class="social-icon" style="color: #0e131f;">&#x1F4F7;</a> <!-- Instagram -->
                <a href="#" class="social-icon" style="color: #0e131f;">&#x1F426;</a> <!-- Twitter -->
            </div>
            <a href="#" class="specialist-btn">SPECIALIST EPCM</a>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="container d-flex justify-content-between align-items-center">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand d-flex align-items-center">
                <img src="https://unsplash.com/photos/a-close-up-of-a-solar-panel-on-a-sunny-day-92xL0sK18kY/download?force=true&w=64&h=64" alt="Solarex Logo" style="height: 30px; margin-right: 10px;">
                SOLAREX
            </a>
            <ul class="navbar-nav">
                <li class="nav-item"><a href="#" class="nav-link">PRODUCTS</a></li>
                <li class="nav-item"><a href="#" class="nav-link">CLEARANCE SALES</a></li>
                <li class="nav-item"><a href="#" class="nav-link">CONTACT US</a></li>
            </ul>
            <div class="d-flex align-items-center">
                <div class="search-bar">
                    <input type="text" placeholder="Keywords, Product Name, etc.">
                    <button class="icon-btn">&#x1F50D;</button> <!-- Search icon -->
                </div>
                <button class="icon-btn" style="margin-left: 1rem;">&#x1F464; SIGN IN</button> <!-- User icon -->
                <button class="icon-btn" style="margin-left: 1rem;">&#x1F6CD; VIEW CART</button> <!-- Cart icon -->
            </div>
        </div>
    </nav>

    <!-- Breadcrumb -->
    <div class="breadcrumb-nav">
        <div class="container">
            <?php woocommerce_breadcrumb(); ?>
        </div>
    </div>

    <!-- Main Content Area for Cart -->
    <section class="container py-4">
        <?php
        // This will render the WooCommerce cart content using the shortcode
        echo do_shortcode('[woocommerce_cart]');
        ?>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-start" style="text-align: left;">
                <div style="flex: 1; min-width: 250px; margin-bottom: 2rem;">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand d-flex align-items-center mb-3">
                        <img src="https://unsplash.com/photos/a-close-up-of-a-solar-panel-on-a-sunny-day-92xL0sK18kY/download?force=true&w=64&h=64" alt="Solarex Logo" style="height: 30px; margin-right: 10px;">
                        SOLAREX
                    </a>
                    <div class="footer-contact-info">
                        <p>&#x260E; +230 220 0050</p>
                        <p>&#x1F4CD; 191/7, La Tour Koenig, Industrial Park, Port Aux Sables, TROU Mauritius</p>
                        <p>&#x2709; <a href="mailto:energy@unitmount.com">energy@unitmount.com</a></p>
                    </div>
                </div>

                <div class="footer-links-group">
                    <div class="footer-links-column">
                        <h5>OUR SOLAR SOLUTIONS</h5>
                        <ul>
                            <li><a href="#">Residential Solar</a></li>
                            <li><a href="#">Commercial Solar</a></li>
                            <li><a href="#">Industrial Solar</a></li>
                            <li><a href="#">Solar Inverters</a></li>
                            <li><a href="#">Mounting Systems</a></li>
                        </ul>
                    </div>
                    <div class="footer-links-column">
                        <h5>OUR PROJECTS</h5>
                        <ul>
                            <li><a href="#">Recent Installations</a></li>
                            <li><a href="#">Case Studies</a></li>
                            <li><a href="#">Upcoming Projects</a></li>
                        </ul>
                    </div>
                    <div class="footer-links-column">
                        <h5>OUR SERVICES</h5>
                        <ul>
                            <li><a href="#">Consultation</a></li>
                            <li><a href="#">Installation</a></li>
                            <li><a href="#">Maintenance</a></li>
                            <li><a href="#">Energy Audits</a></li>
                        </ul>
                    </div>
                    <div class="footer-links-column">
                        <h5>FUNDING SOLUTIONS</h5>
                        <ul>
                            <li><a href="#">Financing Options</a></li>
                            <li><a href="#">Government Grants</a></li>
                            <li><a href="#">Investment Plans</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <hr style="border-color: #777777; margin-top: 2rem; margin-bottom: 1rem;">
            <div class="d-flex flex-wrap justify-content-between align-items-center">
                <p class="footer-copyright m-0">Copyright © <span id="currentYear"></span> Solarex. Powered by WEB COMPANIONZ</p>
                <div class="footer-social-icons m-0">
                    <a href="#" style="color: #ffffff;">&#x1F465;</a> <!-- LinkedIn -->
                    <a href="#" style="color: #ffffff;">&#x1F4F7;</a> <!-- Instagram -->
                    <a href="#" style="color: #0e131f;">&#x1F426;</a> <!-- Twitter -->
                </div>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Update current year in footer
            const currentYearSpan = document.getElementById('currentYear');
            if (currentYearSpan) { // Add check to ensure element exists
                currentYearSpan.textContent = new Date().getFullYear();
            }
        });
    </script>
</body>
</html>