<ul class="lgx-inline lgx-admin-list-get-pro">
    <li>
        <div class="circle-wrapper">
            <div class="lgx-error circle"></div>
            <div class="lgx-pro-icon">

                <?php if(LGX_LS_PLUGIN_META_FIELD_PRO == 'disabled'): ?>
                <a href="https://logichunt.com/product/wordpress-logo-slider/" target="_blank" ><span>Get Pro!</span></a>
                <?php else: ?>
                <a href="https://docs.logichunt.com/logo-slider-wp" target="_blank" ><span>Usage</span></a>
                <?php endif; ?>
            </div>
        </div>
    </li>

    <li class="lgx_hide_md">
        <div class="circle-wrapper">
            <div class="warning circle"></div>
            <div class="lgx-pro-icon">
                <a href="https://demo.logichunt.com/logo-slider-wp" target="_blank" ><span>Demo</span></a>
            </div>
        </div>
    </li>

    <li>
        <div class="circle-wrapper">
            <div class="success circle"></div>
            <div class="lgx-pro-icon">
                <a href="https://logichunt.com/support" target="_blank" ><span>Help</span></a>
            </div>
        </div>
    </li>
</ul>