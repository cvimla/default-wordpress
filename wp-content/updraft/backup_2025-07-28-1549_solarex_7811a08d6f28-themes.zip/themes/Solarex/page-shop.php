<?php
/**
 * Template Name: Shop Page
 */
get_header('shop'); ?>

<style>
:root {
    --bg-primary: #1a1a2e;
    --bg-secondary: #2e2e3a;
    --accent-green: #00ff00;
    --text-white: #ffffff;
    --text-gray: #cccccc;
    --border-radius: 15px;
}

.shop-container {
    background-color: var(--bg-primary);
    min-height: 100vh;
    padding: 40px 20px;
    font-family: 'Arial', sans-serif;
}

.shop-wrapper {
    max-width: 1400px;
    margin: 0 auto;
    display: flex;
    gap: 40px;
}

.shop-sidebar {
    width: 350px;
    background: linear-gradient(135deg, var(--accent-green) 0%, #00cc00 100%);
    border-radius: var(--border-radius);
    padding: 30px;
    height: fit-content;
    position: sticky;
    top: 20px;
}

.sidebar-title {
    font-size: 2.2em;
    font-weight: bold;
    color: var(--bg-primary);
    margin-bottom: 30px;
    line-height: 1.1;
}

.filter-section {
    margin-bottom: 25px;
}

.filter-item {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
    padding: 8px 0;
}

.filter-item:hover {
    transform: translateX(5px);
}

.filter-item input[type="radio"] {
    width: 20px;
    height: 20px;
    margin-right: 15px;
    accent-color: var(--bg-primary);
}

.filter-item label {
    font-size: 1.1em;
    font-weight: 600;
    color: var(--bg-primary);
    cursor: pointer;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.price-filter-section {
    background-color: rgba(26, 26, 46, 0.1);
    padding: 20px;
    border-radius: 10px;
    margin-top: 20px;
}

.price-inputs {
    display: flex;
    gap: 10px;
    margin-bottom: 15px;
}

.price-input {
    flex: 1;
    padding: 10px;
    border: 2px solid var(--bg-primary);
    border-radius: 8px;
    background: white;
    font-size: 1em;
}

.filter-button {
    background-color: var(--bg-primary);
    color: var(--accent-green);
    border: none;
    padding: 12px 20px;
    border-radius: 8px;
    width: 100%;
    cursor: pointer;
    font-size: 1.1em;
    font-weight: bold;
    transition: all 0.3s ease;
}

.filter-button:hover {
    background-color: #0a0a1a;
    transform: translateY(-2px);
}

.products-section {
    flex: 1;
    color: var(--text-white);
}

.section-header {
    text-align: center;
    margin-bottom: 40px;
}

.page-title {
    font-size: 3.5em;
    font-weight: bold;
    color: var(--text-white);
    margin-bottom: 20px;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    margin-bottom: 40px;
}

.product-card {
    background-color: var(--bg-secondary);
    border-radius: var(--border-radius);
    padding: 25px;
    text-align: center;
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.product-card:hover {
    transform: translateY(-10px);
    border-color: var(--accent-green);
    box-shadow: 0 10px 30px rgba(0, 255, 0, 0.2);
}

.product-image {
    width: 100%;
    height: 200px;
    object-fit: contain;
    margin-bottom: 20px;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 0.05);
    padding: 10px;
}

.product-title {
    font-size: 1.3em;
    font-weight: bold;
    color: var(--text-white);
    margin-bottom: 15px;
    line-height: 1.3;
}

.product-price {
    font-size: 1.4em;
    color: var(--accent-green);
    font-weight: bold;
    margin-bottom: 20px;
}

.view-product-btn {
    background-color: var(--accent-green);
    color: var(--bg-primary);
    padding: 12px 25px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    display: inline-block;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.view-product-btn:hover {
    background-color: #00cc00;
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0, 255, 0, 0.4);
}

.loading-spinner {
    display: none;
    text-align: center;
    padding: 40px;
    color: var(--accent-green);
    font-size: 1.2em;
}

.no-products {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-gray);
    font-size: 1.2em;
}

.pagination {
    display: flex;
    justify-content: center;
    margin-top: 40px;
}

.pagination a,
.pagination span {
    background-color: var(--bg-secondary);
    color: var(--text-white);
    padding: 12px 18px;
    margin: 0 5px;
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.pagination a:hover,
.pagination .current {
    background-color: var(--accent-green);
    color: var(--bg-primary);
}
</style>

<div class="shop-container">
    <div class="shop-wrapper">
        <!-- Left Sidebar -->
        <aside class="shop-sidebar">
            <h1 class="sidebar-title">Select<br>Models</h1>
            
            <div class="filter-section">
                <!-- All Products Filter -->
                <div class="filter-item">
                    <input type="radio" name="category_filter" value="" id="all_products" checked>
                    <label for="all_products">ALL</label>
                </div>
                
                <!-- Category Filters -->
                <?php
                $categories = get_categories(array('taxonomy' => 'product_cat', 'hide_empty' => true));
                foreach ($categories as $category) {
                    $category_id = 'cat_' . $category->term_id;
                    echo '<div class="filter-item">';
                    echo '<input type="radio" name="category_filter" value="' . $category->term_id . '" id="' . $category_id . '">';
                    echo '<label for="' . $category_id . '">' . strtoupper($category->name) . '</label>';
                    echo '</div>';
                }
                ?>
            </div>

            <!-- Price Filter Section -->
            <div class="price-filter-section">
                <form method="get" class="price-filter" id="price-filter-form">
                    <div class="price-inputs">
                        <input type="number" name="min_price" placeholder="Min price" class="price-input" 
                               value="<?php echo isset($_GET['min_price']) ? esc_attr($_GET['min_price']) : ''; ?>">
                        <input type="number" name="max_price" placeholder="Max price" class="price-input" 
                               value="<?php echo isset($_GET['max_price']) ? esc_attr($_GET['max_price']) : ''; ?>">
                    </div>
                    <button type="submit" class="filter-button">FILTER BY PRICE</button>
                </form>
            </div>
        </aside>

        <!-- Products Section -->
        <main class="products-section">
            <div class="section-header">
                <h2 class="page-title">Solar Panel</h2>
            </div>

            <div class="loading-spinner" id="loading-spinner">
                Loading products...
            </div>

            <div id="products-container">
                <?php
                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => 12,
                    'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
                );

                // Handle category filtering
                if (isset($_GET['category_filter']) && !empty($_GET['category_filter'])) {
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field' => 'term_id',
                            'terms' => intval($_GET['category_filter']),
                        ),
                    );
                }

                // Handle price filtering
                if (isset($_GET['min_price']) || isset($_GET['max_price'])) {
                    $args['meta_query'] = array('relation' => 'AND');
                    if (isset($_GET['min_price']) && !empty($_GET['min_price'])) {
                        $args['meta_query'][] = array(
                            'key' => '_price',
                            'value' => floatval($_GET['min_price']),
                            'compare' => '>=',
                            'type' => 'NUMERIC'
                        );
                    }
                    if (isset($_GET['max_price']) && !empty($_GET['max_price'])) {
                        $args['meta_query'][] = array(
                            'key' => '_price',
                            'value' => floatval($_GET['max_price']),
                            'compare' => '<=',
                            'type' => 'NUMERIC'
                        );
                    }
                }

                $products = new WP_Query($args);
                ?>

                <div class="products-grid" id="products-grid">
                    <?php if ($products->have_posts()) : ?>
                        <?php while ($products->have_posts()) : $products->the_post(); ?>
                            <div class="product-card">
                                <a href="<?php the_permalink(); ?>">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('medium', array('class' => 'product-image')); ?>
                                    <?php else : ?>
                                        <div class="product-image" style="background-color: rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; color: #666;">No Image</div>
                                    <?php endif; ?>
                                    <h3 class="product-title"><?php the_title(); ?></h3>
                                </a>
                                <p class="product-price"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="view-product-btn">View Product</a>
                            </div>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <div class="no-products">No products found.</div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if ($products->max_num_pages > 1) : ?>
                    <div class="pagination">
                        <?php
                        echo paginate_links(array(
                            'total' => $products->max_num_pages,
                            'current' => max(1, get_query_var('paged')),
                            'prev_text' => '‹ Previous',
                            'next_text' => 'Next ›',
                        ));
                        ?>
                    </div>
                <?php endif; ?>

                <?php wp_reset_postdata(); ?>
            </div>
        </main>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Handle category filter clicks
    $('input[name="category_filter"]').on('change', function() {
        filterProducts();
    });
    
    // Handle price filter form submission
    $('#price-filter-form').on('submit', function(e) {
        e.preventDefault();
        filterProducts();
    });
    
    function filterProducts() {
        const selectedCategory = $('input[name="category_filter"]:checked').val();
        const minPrice = $('input[name="min_price"]').val();
        const maxPrice = $('input[name="max_price"]').val();
        
        // Show loading spinner
        $('#loading-spinner').show();
        $('#products-grid').hide();
        
        // Build URL parameters
        const params = new URLSearchParams();
        if (selectedCategory) {
            params.append('category_filter', selectedCategory);
        }
        if (minPrice) {
            params.append('min_price', minPrice);
        }
        if (maxPrice) {
            params.append('max_price', maxPrice);
        }
        
        // Update URL without page reload
        const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
        window.history.pushState({}, '', newUrl);
        
        // AJAX request to filter products
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'filter_products',
                category_filter: selectedCategory,
                min_price: minPrice,
                max_price: maxPrice,
                nonce: '<?php echo wp_create_nonce('filter_products_nonce'); ?>'
            },
            success: function(response) {
                $('#loading-spinner').hide();
                $('#products-container').html(response);
                $('#products-grid').show();
            },
            error: function() {
                $('#loading-spinner').hide();
                $('#products-grid').show();
                alert('Something went wrong. Please try again.');
            }
        });
    }
    
    // Set initial filter state based on URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const categoryParam = urlParams.get('category_filter');
    const minPriceParam = urlParams.get('min_price');
    const maxPriceParam = urlParams.get('max_price');
    
    if (categoryParam) {
        $('input[name="category_filter"][value="' + categoryParam + '"]').prop('checked', true);
    }
    if (minPriceParam) {
        $('input[name="min_price"]').val(minPriceParam);
    }
    if (maxPriceParam) {
        $('input[name="max_price"]').val(maxPriceParam);
    }
});
</script>

<?php get_footer('shop'); ?>