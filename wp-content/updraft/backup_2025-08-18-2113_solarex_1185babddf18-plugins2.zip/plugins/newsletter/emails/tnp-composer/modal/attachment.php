<div id="tnpc-attachment-modal" aria-hidden="true" style="display: none">
    <p>
        <?php esc_html_e('Attachments are not supported.')?>
        <a href="https://www.thenewsletterplugin.com/documentation/adding-attachments-to-newsletters/" target="_blank"><?php esc_html_e('Read more.')?></a>.
    </p>
</div>
