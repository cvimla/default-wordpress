<?php
if (!defined('ABSPATH')) exit;
?>
<table class="form-table">
    <tr>
        <th><?php _e('Disable social links', 'newsletter') ?></th>
        <td><?php $controls->checkbox('theme_social_disable', ''); ?></td>
    </tr>
</table>