<div id="tnpc-attachment-modal" aria-hidden="true" class="modal">
    <p>
        <?php esc_html_e('Attachments are not supported.')?>
        <a href="https://www.thenewsletterplugin.com/documentation/adding-attachments-to-newsletters/" target="_blank"><?php esc_html_e('Read more.')?></a>.
    </p>
</div>
