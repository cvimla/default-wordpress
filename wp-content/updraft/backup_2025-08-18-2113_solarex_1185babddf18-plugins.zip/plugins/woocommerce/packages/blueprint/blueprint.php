<?php
/**
 * Plugin Name: Blueprint
 * Plugin URI: https://woocommerce.com/
 * Description: An empty blueprint definition file to setup wp-env test env.
 * Version: 0.0.1
 * Author: Automattic
 * Author URI: https://woocommerce.com
 * Requires at least: 6.4
 * Requires PHP: 7.4
 */
