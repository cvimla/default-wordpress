<?php
/**
 * Template Name: Best Inverters
 */
get_header(); ?>

<div class="container mx-auto my-8 text-center" style="background-color: #1a1a2e; color: #fff; padding: 20px;">
    <h1 style="font-size: 2em; color: #00ff00; margin-bottom: 10px;">Our Best Inverters</h1>
    <p style="font-size: 1em; margin-bottom: 20px;">Smart and Outdoor high voltage inverters.</p>

    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 20px;">
        <?php
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => 'inverter',
                ),
            ),
        );

        $products = new WP_Query($args);
        if ($products->have_posts()) : while ($products->have_posts()) : $products->the_post(); ?>
            <div style="background-color: #2e2e3a; padding: 20px; border-radius: 10px; text-align: center;">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('medium'); ?>
                    <h3 style="font-size: 1.1em; margin: 10px 0;"><?php the_title(); ?></h3>
                </a>
                <p style="font-size: 0.9em; color: #00ff00;"><?php echo wc_price(get_post_meta(get_the_ID(), '_price', true)); ?></p>
                <a href="<?php echo esc_url(get_permalink()); ?>" style="background-color: #00ff00; color: #1a1a2e; padding: 5px 10px; border-radius: 5px; text-decoration: none; display: inline-block;">View Product</a>
            </div>
        <?php endwhile; wp_reset_postdata(); else : ?>
            <p>No products found.</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>